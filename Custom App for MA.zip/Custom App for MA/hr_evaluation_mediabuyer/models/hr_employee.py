from odoo import models, fields, api
from datetime import datetime


class Employee(models.Model):
    _inherit = 'hr.employee'

    is_mediabuyer = fields.Boolean()
    evaluation_year_id = fields.One2many("hr.evaluation.year", "employee_id")
