from odoo import models, fields, api
from datetime import datetime


class HrEvaluationYear(models.Model):
    _name = 'hr.evaluation.year'
    _description = "Evaluation Year"

    year = fields.Char("Year", required=True)
    employee_id = fields.Many2one("hr.employee")
    evaluation_mediabuyer_id = fields.One2many("hr.evaluation.mediabuyer", "evaluation_year_id")

    manager_remarks = fields.Html("Manager Remarks")
    hr_remarks = fields.Html("HR Remarks")

