# -*- coding: utf-8 -*-

from . import hr_employee
from . import hr_evaluation_year 

from . import hr_evaluation_mediabuyer
from . import hr_quarter_name
