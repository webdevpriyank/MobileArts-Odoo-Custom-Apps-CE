from odoo import models, fields, api
from datetime import datetime


class HrEvaluationMediabuyer(models.Model):
    _name = 'hr.evaluation.mediabuyer'
    _description = "Evaluation of Mediabuyer"

    quarter_name_id = fields.Many2one("hr.quarter.name")
    revenue_earned = fields.Float("Revenue Earned(USD)")
    amount_spent = fields.Float("Amount Spent(USD)")
    profit_margin = fields.Float(string='Profit Margin(USD)', compute='_compute_profit_margin', store=True)
    roi = fields.Float(string='ROI(USD)', compute='_compute_roi', store=True)
    evaluation_year_id = fields.Many2one("hr.evaluation.year")

    evaluation = fields.Selection(string="Evaluation", selection=[('true', 'True'),('false', 'False'), ('neutral', 'Neutral')])


    @api.depends('revenue_earned', 'amount_spent')
    def _compute_profit_margin(self):
        for entry in self:
            if entry.revenue_earned and entry.amount_spent:
                entry.profit_margin = entry.revenue_earned - entry.amount_spent
    
    @api.depends('revenue_earned', 'amount_spent')
    def _compute_roi(self):
        for entry in self:
            if entry.revenue_earned and entry.amount_spent:
                entry.roi = (entry.revenue_earned - entry.amount_spent)/ entry.amount_spent

