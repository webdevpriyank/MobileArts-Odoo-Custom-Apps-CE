from odoo import models, fields, api
from datetime import datetime


class HrQuarterName(models.Model):
    _name = 'hr.quarter.name'
    _description = "Quarter name"


    name = fields.Char("Quarter name")
    