# -*- coding: utf-8 -*-
# from odoo import http


# class AppraisalMediabuyer(http.Controller):
#     @http.route('/appraisal_mediabuyer/appraisal_mediabuyer', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/appraisal_mediabuyer/appraisal_mediabuyer/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('appraisal_mediabuyer.listing', {
#             'root': '/appraisal_mediabuyer/appraisal_mediabuyer',
#             'objects': http.request.env['appraisal_mediabuyer.appraisal_mediabuyer'].search([]),
#         })

#     @http.route('/appraisal_mediabuyer/appraisal_mediabuyer/objects/<model("appraisal_mediabuyer.appraisal_mediabuyer"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('appraisal_mediabuyer.object', {
#             'object': obj
#         })

