from odoo import models, fields, api
from datetime import datetime

class employeeFields(models.Model):
    _inherit = "hr.employee"

    x_global_code = fields.Char(string="Global Dimension 2 Code")
    x_company_phone_ext = fields.Char(string="Work Phone Ext")
    x_bank_branch_no = fields.Char(string="Bank Branch No")
    x_swift_code = fields.Char(string="SWIFT Code")
    x_first_name = fields.Char(string="First Name")
    x_middle_name = fields.Char(string="Middle Name")
    x_last_name = fields.Char(string="last Name")
    x_search_name = fields.Char(string="Search Name")
    x_mother_name = fields.Char(string="Mother Name")
    x_nssf_no = fields.Char(string="NSSF No.")
    x_nssf_date = fields.Date(string="NSSF Date")
    x_full_name_arabic = fields.Char(string="الإسم الثلاثي")
    x_name_arabic = fields.Char(string="الإسم")
    x_name_of_father_arabic = fields.Char(string="إسم الأب")
    x_surname_arabic = fields.Char(string="الشهرة")
    x_name_of_mother_arabic = fields.Char(string="إسم الوالدة")
    x_personal_finance_no = fields.Char(string="Personal Finance No.")
    x_identity_card_no = fields.Char(string="Identity Card No.")
    x_first_nationality_code = fields.Char(string="First Nationality Code")
    # x_ = fields.Char(string="")
    x_emp_category_code = fields.Char(string="Employee Category Code")
    x_tax_status = fields.Char(string="Tax Status")
    x_emp_type_code = fields.Char(string="Employment Type Code")
    x_spouse_husband_secured = fields.Selection(string="Spouse / Husband Secured", selection=[
        ('false', 'No'),
        ('true', 'Yes'),
    ], default='false')
    x_registration_no_arabic = fields.Char(string="رقم السجل")
    x_passport_issue_date = fields.Date(string="Passport Issue Date")
    x_passport_expiry_date = fields.Date(string="Passport Expiry Date")
    x_is_foreigner = fields.Char(string="Is Foreigner?")
    x_blood_group = fields.Char(string="Blood Group")
    x_iban_no = fields.Char(string="IBAN No")
    x_divorced_spouse_child_resp = fields.Char(string="Divorced Spouse Child. Resp.")
    x_spouse_work = fields.Char(string="Spouse Work")
    x_husband_unemployed = fields.Char(string="Husband Unemployed")
    x_emp_bank_account_no = fields.Char(string="Emp. Bank Account No")
    x_chronic_disease = fields.Char(string="Chronic Disease")

    x_employment_date = fields.Date(string="Employment Date")

    x_privacy_blocked = fields.Selection(string="Privacy Blocked", selection=[
        ('true', 'True'),
        ('false', 'False'),
    ], default='false')

    x_rate_indicator = fields.Selection(string="Rate Indicator", selection=[
        ('weekly', 'Weekly'),
        ('monthly', 'Monthly'),
        ('quarterly', 'Quarterly'),
        ('half_yearly', 'Half Yearly'),
        ('yearly', 'Yearly'),
    ], default='monthly')

    x_pay_frequency = fields.Selection(string="Pay Frequency", selection=[
        ('weekly', 'Weekly'),
        ('monthly', 'Monthly'),
        ('quarterly', 'Quarterly'),
        ('half_yearly', 'Half Yearly'),
        ('yearly', 'Yearly'),
    ], default='monthly')

    x_payment_method = fields.Selection(string="Payment Method", selection=[
        ('cash', 'Cash'),
        ('bank', 'Bank'),
    ], default='bank')
    x_director = fields.Selection(string="Director", selection=[
        ('true', 'True'),
        ('false', 'False'),
    ], default='false')

    x_prev_social_security_reg = fields.Char(string="Previous Social Security Registration")
    x_no_exemption = fields.Char(string="No Exemption")
    x_labor_type = fields.Selection(string="Labor Type", selection=[
        ('0', ''),
        ('1', 'Driver'),
        ('2', 'labor'),
    ], default='0')

    x_age = fields.Integer(compute='_compute_age')

    @api.depends('birthday')
    def _compute_age(self):
        for record in self:
            if record.birthday:
                dob = fields.Datetime.to_datetime(record.birthday)
                now = datetime.now()
                delta = now - dob
                record.x_age = int(delta.days / 365.25)
            else:
                record.x_age = 0

    x_service_years = fields.Float(compute='_compute_seryear', string="Service Years")

    @api.depends('x_employment_date')
    def _compute_seryear(self):
        for record in self:
            if record.x_employment_date:
                sy = fields.Datetime.to_datetime(record.x_employment_date)
                now = datetime.now()
                delta = now - sy
                years = delta.days / 365.25
                months = (years % 1) * 12
                record.x_service_years = round(years // 1 + months / 10, 2)
            else:
                record.x_service_years = 0.0

    x_end_of_service_date = fields.Date(compute='_compute_eoserdate', string="End of Service Date")

    @api.depends('birthday')
    def _compute_eoserdate(self):
        for record in self:
            if record.birthday:
                birth_date = fields.Datetime.to_datetime(record.birthday)
                retirement_age = 64
                end_of_service_date = birth_date.replace(year=birth_date.year + retirement_age)
                record.x_end_of_service_date = end_of_service_date
            else:
                record.x_end_of_service_date = None

    # x_notification_list = fields.Char(string="Enter Email IDs")