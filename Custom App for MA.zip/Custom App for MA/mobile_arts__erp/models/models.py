# -*- coding: utf-8 -*-

# from odoo import models, fields, api


# class mobile_arts__erp(models.Model):
#     _name = 'mobile_arts__erp.mobile_arts__erp'
#     _description = 'mobile_arts__erp.mobile_arts__erp'

#     name = fields.Char()
#     value = fields.Integer()
#     value2 = fields.Float(compute="_value_pc", store=True)
#     description = fields.Text()
#
#     @api.depends('value')
#     def _value_pc(self):
#         for record in self:
#             record.value2 = float(record.value) / 100

