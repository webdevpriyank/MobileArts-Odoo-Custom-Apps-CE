# -*- coding: utf-8 -*-
# from odoo import http


# class MobileArtsErp(http.Controller):
#     @http.route('/mobile_arts__erp/mobile_arts__erp', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/mobile_arts__erp/mobile_arts__erp/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('mobile_arts__erp.listing', {
#             'root': '/mobile_arts__erp/mobile_arts__erp',
#             'objects': http.request.env['mobile_arts__erp.mobile_arts__erp'].search([]),
#         })

#     @http.route('/mobile_arts__erp/mobile_arts__erp/objects/<model("mobile_arts__erp.mobile_arts__erp"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('mobile_arts__erp.object', {
#             'object': obj
#         })

