# -*- coding: utf-8 -*-
# from odoo import http


# class CustomApproveRefuse(http.Controller):
#     @http.route('/custom_approve_refuse/custom_approve_refuse', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/custom_approve_refuse/custom_approve_refuse/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('custom_approve_refuse.listing', {
#             'root': '/custom_approve_refuse/custom_approve_refuse',
#             'objects': http.request.env['custom_approve_refuse.custom_approve_refuse'].search([]),
#         })

#     @http.route('/custom_approve_refuse/custom_approve_refuse/objects/<model("custom_approve_refuse.custom_approve_refuse"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('custom_approve_refuse.object', {
#             'object': obj
#         })

