from odoo import models, fields, api


class HrLeaveallocation(models.Model):
    _inherit = 'hr.leave.allocation'

    filtered_employee_ids = fields.Many2many(
        'hr.employee',
        compute='_compute_filtered_employee_ids',
        string='Filtered Employees'
    )


@api.depends('employee_id')
def _compute_filtered_employee_ids(self):
    for record in self:
        if self.env.user.has_group('hr.group_hr_manager'):
            # If the user is a manager, filter employees they manage
            employees = self.env['hr.employee'].search([('parent_id.user_id', '=', self.env.user.id)])
        else:
            # If the user is not a manager (e.g., admin), show all employees
            employees = self.env['hr.employee'].search([])

        record.filtered_employee_ids = employees