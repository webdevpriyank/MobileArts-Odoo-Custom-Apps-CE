from odoo import models, fields, api, _
from odoo.exceptions import UserError


class HrLeave(models.Model):
        _inherit = 'hr.leave'

        @api.depends('state', 'employee_id.user_id')
        def _compute_button_visibility(self):
            for record in self:
                if self.env.user.has_group('hr.group_hr_manager'):
                    if record.user_id.id == self.env.user.id:
                        record.can_approve = False
                        record.refuse_button_visible = False

                    else:
                        record.can_approve = True
                        record.refuse_button_visible = True

                else:
                    record.can_approve = False
                    record.refuse_button_visible = False

        can_approve = fields.Boolean(string="Approve Button Visible", compute='_compute_button_visibility')
        refuse_button_visible = fields.Boolean(string="Refuse Button Visible", compute='_compute_button_visibility')

        def unlink(self):
            for leave in self:
                # Check if the current user is deleting their own record
                if leave.employee_id.user_id == self.env.user:
                    manager_name = leave.employee_id.parent_id.name or _("No manager assigned")
                    raise UserError(_("You cannot delete your own time off request. Please ask your manager %s to delete it for you.") % manager_name)

                # Allow managers to delete any time off requests
                if self.env.user.has_group('hr_holidays.group_hr_holidays_manager'):
                    continue

                elif leave.employee_id.parent_id.user_id != self.env.user:
                        raise UserError(_("You cannot delete this time off request because it does not belong to one of your employees."))

                # For non-managers, raise an error if they try to delete any time off request other than their own

            return super(HrLeave, self).unlink()


        @api.model
        def default_get(self, fields_list):
            res = super(HrLeave, self).default_get(fields_list)
            res['holiday_status_id'] = False
            return res

