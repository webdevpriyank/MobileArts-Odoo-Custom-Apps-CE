from odoo import models, fields, api


class time_off_modal(models.Model):
    _inherit = 'hr.leave'

    x_employee_ids = fields.Many2many(
        'hr.employee',
        'hr_leave_hr_employee_rel',  # Unique relation table
        'leave_id',  # Column for 'hr.leave' model
        'employee_id',  # Column for 'hr.employee' model
        string='Select employees to notify'
    )
    x_notification_list = fields.Char(string="Email for Notification", compute='_compute_employee_emails')

    @api.depends('x_employee_ids')
    def _compute_employee_emails(self):
        emails = []
        for employee in self.x_employee_ids:
            if employee.work_email:
                emails.append(employee.work_email)
        self.x_notification_list = ', '.join(emails)