# Copyright (C) 2004-2010 Tiny SPRL (<http://tiny.be>).
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).
{

    "name": "Document Page Department Access",
    "summary": "Choose department to access document pages",
    "version": "17.0.1.0.0",
    "category": "document_knowledge",
    "website": "https://github.com/OCA/knowledge",
    "author": "Sygel, Odoo Community Association (OCA)",
    "license": "AGPL-3",
    "application": False,
    "installable": True,
    "depends": [
        "document_page",
        "document_knowledge",
    ],
    "data": ["views/document_page.xml", "security/security.xml"],
}