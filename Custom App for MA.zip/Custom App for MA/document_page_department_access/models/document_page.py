from odoo import models, fields


class DocumentPage(models.Model):
    _inherit = "document.page"

    department_id = fields.Many2one("hr.department", "Department")
    