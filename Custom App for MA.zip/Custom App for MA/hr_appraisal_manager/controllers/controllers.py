# -*- coding: utf-8 -*-
# from odoo import http


# class HrKpiManagement(http.Controller):
#     @http.route('/hr_appraisal_manager/hr_appraisal_manager', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/hr_appraisal_manager/hr_appraisal_manager/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('hr_appraisal_manager.listing', {
#             'root': '/hr_appraisal_manager/hr_appraisal_manager',
#             'objects': http.request.env['hr_appraisal_manager.hr_appraisal_manager'].search([]),
#         })

#     @http.route('/hr_appraisal_manager/hr_appraisal_manager/objects/<model("hr_appraisal_manager.hr_appraisal_manager"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('hr_appraisal_manager.object', {
#             'object': obj
#         })

