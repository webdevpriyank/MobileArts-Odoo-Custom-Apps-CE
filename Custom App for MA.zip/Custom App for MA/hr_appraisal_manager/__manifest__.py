# -*- coding: utf-8 -*-
{
    'name': "HR Kpi Manager",

    'summary': "Enhances employee form view by adding visibility control for the appraisal page based on custom conditions.",

    'description': """
       This module extends the existing HR employee form view to include additional visibility control for the appraisal page.
        It introduces a new field, `is_in_appraisal_group`, to manage visibility. The appraisal page will be visible if either
        this field is set to True or if a condition from another module is met. This allows for more flexible visibility control
        based on multiple conditions.    """,

    'author': "Omkar Bari (Mobibox Softech Pvt Ltd)",
    'website': "https://mobiboxsoftech.com/",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/15.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'version': '1.1',

    # any module necessary for this one to work correctly
    'depends': ['base','hr','kpi_management_system'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'security/security.xml',
        'views/views.xml',
        'views/HrManagement.xml',
        'views/templates.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
}

