/** @odoo-module **/

import { registry } from "@web/core/registry";
import { KanbanRenderer } from "@web/views/kanban/kanban_renderer";

export class CopyToClipboardKanbanRenderer extends KanbanRenderer {
    setup() {
        super.setup();
        // Bind event listeners
        this._on('click .o_copy_clipboard', this._onCopyToClipboard.bind(this));
    }

    /**
     * Handle the copy button click event.
     * @private
     */
    _onCopyToClipboard(event) {
        event.preventDefault();
        const button = event.currentTarget;
        const text = button.dataset.text; // Use 'data-text' attribute for text to copy

        if (!text) {
            return;
        }

        // Create a temporary input element to copy the text
        const tempInput = document.createElement('input');
        document.body.appendChild(tempInput);
        tempInput.value = text;
        tempInput.select();
        document.execCommand('copy');
        document.body.removeChild(tempInput);

        // Notify user that text has been copied using a basic alert
        alert('Text has been copied to clipboard.');
    }
}

export const CopyToClipboardKanbanView = {
    ...KanbanRenderer,
    Renderer: CopyToClipboardKanbanRenderer,
};

registry.category("views").add("copy_to_clipboard_kanban", CopyToClipboardKanbanView);
