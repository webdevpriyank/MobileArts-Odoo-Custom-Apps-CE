# -*- coding: utf-8 -*-
# from odoo import http


# class FolderLinkTracker(http.Controller):
#     @http.route('/get_document_url/get_document_url', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/get_document_url/get_document_url/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('get_document_url.listing', {
#             'root': '/get_document_url/get_document_url',
#             'objects': http.request.env['get_document_url.get_document_url'].search([]),
#         })

#     @http.route('/get_document_url/get_document_url/objects/<model("get_document_url.get_document_url"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('get_document_url.object', {
#             'object': obj
#         })

