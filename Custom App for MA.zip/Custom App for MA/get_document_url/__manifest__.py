# -*- coding: utf-8 -*-
{
    'name': "Uploaded Files/Images Url",

    'summary': "This module will provide link for every document you share in folder "
               "",

    'description': """
        1.This module is depends on Document_folder management which is an module for creating an sharing a folder to user.
            2.This module will provide you an link for each and every document you uploaded in folder,you can share that link to user to view the document.
            3.The delete permission is only for the user who have created a folder""",

    'author': "Omkar Ashish Bari @Mobibox Softech Pvt Ltd",
    'website': "https://mobiboxsoftech.com/",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/15.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base','document_management','folder_employee_access','document_folder_access', 'mail'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'security/security.xml',
        'views/MenuViewsEdited.xml',
        'views/link_tracker.xml',
        'views/document_url_form.xml',
        'views/templates.xml',
    ],

   'assets': {
        'web.assets_backend': [
            'get_document_url/static/src/img/folder.svg',
            'get_document_url/static/src/js/copy_url.js',
            'get_document_url/static/src/css/search.css',
        ],
    },
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
   'icon': '/get_document_url/static/description/icon.png'
}

