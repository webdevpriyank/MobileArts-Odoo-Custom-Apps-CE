from odoo import models, fields, api, _
from odoo.exceptions import AccessError, MissingError
import logging

_logger = logging.getLogger(__name__)

class DocumentExtraFolderInherited(models.Model):
    _inherit = 'document.extra.folder'

    @api.onchange('employee_ids')
    def _onchange_employee_ids(self):
        """
        Automatically include the current user as an employee if any other employee is selected.
        Do not add the current user if no employees are selected.
        """
        current_employee = self.env.user.employee_id
        if self.employee_ids and current_employee:
            # Check if the current user is not already included
            if current_employee not in self.employee_ids:
                self.employee_ids |= current_employee
        elif not self.employee_ids:
            # If no employees are selected, do not add the current employee
            self.employee_ids = [(5, 0, 0)]  # Clear the employee list

    @api.model_create_single
    def create(self, vals):
        # Ensure the current user is included in the employee_ids when creating a record if any employee is selected
        current_employee = self.env.user.employee_id
        if 'employee_ids' in vals and current_employee:
            employee_ids = vals.get('employee_ids', [])

            if employee_ids and isinstance(employee_ids[0], list) and len(employee_ids[0]) > 2:
                employee_ids_list = employee_ids[0][2]
                if employee_ids_list and current_employee.id not in employee_ids_list:
                    employee_ids_list.append(current_employee.id)
                vals['employee_ids'] = [(6, 0, employee_ids_list)]
            elif not employee_ids:
                # Do nothing if no employees are selected
                pass

        folder = super(DocumentExtraFolderInherited, self).create(vals)

        # Assign employees to the parent folder if it exists
        if folder.parent_id:
            folder.parent_id.write({'employee_ids': [(4, emp_id.id) for emp_id in folder.employee_ids]})

        # Check if a corresponding record already exists in document.folder
        folder_record = self.env['document.folder'].search([('parent_id', '=', folder.id)], limit=1)
        if folder_record:
            folder_record.write({'employee_ids': [(6, 0, folder.employee_ids.ids)]})
        else:
            # Create a record in document.folder for the current folder
            self.env['document.folder'].create({
                'parent_id': folder.id,
                'employee_ids': [(6, 0, folder.employee_ids.ids)],
            })

        # Ensure the parent folder in document.folder also gets the employees
        if folder.parent_id:
            parent_folder_record = self.env['document.folder'].search([('parent_id', '=', folder.parent_id.id)],
                                                                      limit=1)
            if parent_folder_record:
                parent_folder_record.write({'employee_ids': [(6, 0, folder.employee_ids.ids)]})
            else:
                self.env['document.folder'].create({
                    'parent_id': folder.parent_id.id,
                    'employee_ids': [(6, 0, folder.employee_ids.ids)],
                })

        return folder

    def write(self, vals):
        res = super(DocumentExtraFolderInherited, self).write(vals)
        for folder in self:
            if 'employee_ids' in vals:
                # Ensure the current user is included in the employee_ids when writing a record if any employee is selected
                current_employee = self.env.user.employee_id
                if folder.employee_ids and current_employee and current_employee.id not in folder.employee_ids.ids:
                    folder.employee_ids |= current_employee
                elif not folder.employee_ids:
                    # Do nothing if no employees are selected
                    pass

                if folder.parent_id:
                    folder.parent_id.write({'employee_ids': [(4, emp_id.id) for emp_id in folder.employee_ids]})

                    # Update the corresponding document.folder records
                    folder_record = self.env['document.folder'].search([('parent_id', '=', folder.id)], limit=1)
                    if folder_record:
                        folder_record.write({'employee_ids': [(6, 0, folder.employee_ids.ids)]})

                    parent_folder_record = self.env['document.folder'].search([('parent_id', '=', folder.parent_id.id)],
                                                                              limit=1)
                    if parent_folder_record:
                        parent_folder_record.write({'employee_ids': [(6, 0, folder.employee_ids.ids)]})

        return res

