# -*- coding: utf-8 -*-
{
    'name': "Account Farming",

    'summary': "Account Farming App to help manage Account Inventory and Documents",

    'description': """
Account Farming App to help manage Account Inventory and Documents
    """,

    'author': "Priyank Desai @MobiBox Softech Private Limited",
    'website': "https://www.mobiboxsoftech.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/15.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Tools',
    'version': '1.3',

    # any module necessary for this one to work correctly
    'depends': ['base','mail'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'views/views.xml',
        'views/app_inventory_management_view.xml',
        'views/templates.xml',
        # 'data/email_template.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
    'installable': True,
    'auto_install': False,
    'application': True,
    'icon': '/app_farming/static/description/icon.png'
}

