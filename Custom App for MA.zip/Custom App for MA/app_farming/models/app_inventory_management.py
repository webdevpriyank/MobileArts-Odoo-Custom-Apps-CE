# In your models.py
from odoo import models, fields, api
from odoo.exceptions import ValidationError
import re
from datetime import date


class AppInventoryManagement(models.Model):
    _name = 'appfarming.inventory'
    _description = 'App Farming Inventory'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    STATUS_SELECTION = [
        ('in_progress', 'In Progress'),
        ('in_verification', 'In Verification'),
        ('verified', 'Verified'),
        ('terminated', 'Terminated'),
        ('in_transfer', 'In Transfer'),
        ('published', 'Published'),
        ('pending_for_SDK_integration', 'Pending for SDK Integration'),
        ('in_use', 'In Use'),
        ('update_in_review', 'Update in Review'),
        ('terminated_before_live', 'Terminated Before Live')
    ]

    PROXY_PROVIDER = [
        ('astroproxy', 'Astroproxy'),
        ('oxylabs', 'Oxylabs'),
        ('iRoyal', 'IPRoyal'),
        ('brightdata', 'Brightdata')
    ]

    ACC_TYPE_SELECTION = [
        ('personal', 'Personal'),
        ('corporate', 'Corporate')
    ]

    ID_SELECTION = [
        ('voterid', 'Voter ID Card'),
        ('driving_license', 'Driving License'),
        ('passport', 'Passport'),
    ]

    full_name = fields.Char(string='Full Name', required=True)
    address = fields.Text(string='Address', required=True)
    email = fields.Char(string='Email', required=True, searchable=True)
    password = fields.Char(string='Password', required=True)
    account_type = fields.Selection(string='Account Type', selection=ACC_TYPE_SELECTION, required=True)
    phone_number = fields.Char(string='Phone Number', required=True)
    backup_codes = fields.Text(string='Backup Codes', required=True)
    id_type = fields.Selection(string='ID Proof Type', selection=ID_SELECTION, required=True)
    id_number = fields.Char(string='ID Proof Verification No', required=True)
    device_imei = fields.Char(string='Device IMEI', required=True)
    device_sn = fields.Char(string='Device Serial No', required=True)
    card_no = fields.Char(string='Card Number', required=True)
    exp_date = fields.Char(string='Expiry Date', required=True)
    cvv_no = fields.Char(string='CVV', required=True)
    order_no = fields.Char(string='Order Number', required=True)
    account_id = fields.Char(string='Account ID', required=True)
    note = fields.Text(string='Note')
    status = fields.Selection(string='Status', selection=STATUS_SELECTION)
    proxy_provider = fields.Selection(string='Proxy Provider', selection=PROXY_PROVIDER, default='')
    creator_id = fields.Many2one('res.users', string='Creator', default=lambda self: self.env.user.id,
                                 readonly=True, index=True, store=True)
    document_ids = fields.Many2many('ir.attachment', string='Documents')

    # created_date = fields.Date(string='Created Date', default=fields.Date.context_today)

    @api.constrains('exp_date')
    def _check_exp_date(self):
        exp_date_pattern = re.compile(r'^(0[1-9]|1[0-2])/([0-9]{2})$')
        for record in self:
            if not exp_date_pattern.match(record.exp_date):
                raise ValidationError("Expiry Date must be in the format MM/YY eg. 04/23")

    @api.constrains('card_no')
    def _check_card_no(self):
        for record in self:
            if len(record.card_no) != 16 or not record.card_no.isdigit():
                raise ValidationError("Card Number must be exactly 16 digits long.")

    @api.constrains('cvv_no')
    def _check_cvv_no(self):
        for record in self:
            if len(record.cvv_no) != 3 or not record.cvv_no.isdigit():
                raise ValidationError("CVV 3 Digit Number eg. 677")

    @api.model
    def _search_custom_method(self, operator, value):
        domain = [('email', operator, value)]
        return domain

    @api.model
    def _search_custom(self, args, offset=0, limit=None, order=None, count=False):
        domain = self._search_custom_method('ilike', args)
        return self.search(domain, offset=offset, limit=limit, order=order, count=count)

