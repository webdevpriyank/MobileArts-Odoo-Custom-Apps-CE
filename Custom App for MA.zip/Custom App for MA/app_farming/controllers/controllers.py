# -*- coding: utf-8 -*-
# from odoo import http


# class AppFarming(http.Controller):
#     @http.route('/app_farming/app_farming', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/app_farming/app_farming/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('app_farming.listing', {
#             'root': '/app_farming/app_farming',
#             'objects': http.request.env['app_farming.app_farming'].search([]),
#         })

#     @http.route('/app_farming/app_farming/objects/<model("app_farming.app_farming"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('app_farming.object', {
#             'object': obj
#         })

