# -*- coding: utf-8 -*-
{
    'name': "html_attachment",
    'version': '0.1',
    'category': 'Uncategorized',


    'summary': "Changed the HTML field view for attachment",

    'description': """
        Before, while uploading document only document symbol as image was displayed without name so it was difficult to identify the document with its name.
        Now with this module the document name is also displayed along with symbol.

        Author: Surabhi Varma (Mobibox Softech Pvt Ltd)
        Website: https://www.mobiboxsoftech.com

    """,

    'author': 'Surabhi Varma (Mobibox Softech Pvt Ltd.)',
    'website': 'https://mobiboxsoftech.com/',

    'depends': ['web', 'web_editor'],
    'data': [
    ],
    'assets': {
        'web.assets_backend': [
            'html_attachment/static/src/components/html_attach/document_selector.js',
            'html_attachment/static/src/scss/document_selector.scss',
        ],
        'web_editor.backend_assets_wysiwyg': [
            'html_attachment/static/src/components/html_attach/wsysiwyg.js',

        ]

    },
    'demo': [
    ],
    'installable': True,
    'license': 'LGPL-3',

}
