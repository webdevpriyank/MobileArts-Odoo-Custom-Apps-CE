/** @odoo-module **/

import { Wysiwyg } from "@web_editor/js/wysiwyg/wysiwyg";
import { patch } from "@web/core/utils/patch";
import * as OdooEditorLib from "@web_editor/js/editor/odoo-editor/src/OdooEditor";


patch(Wysiwyg.prototype, {
    async startEdition() {
        const isProtected = OdooEditorLib.isProtected;

        const res = await super.startEdition(...arguments);
        
        this.$editable.on('click', '.o_image, .media_iframe_video, .document_link', ev => {
            ev.preventDefault();
            console.log("Event", ev)
        });

        const basicMediaSelector = 'img, .fa, .o_image, .media_iframe_video, .document_link';
        const mediaSelector = basicMediaSelector.split(',').map(s => `${s}:not([data-oe-xpath])`).join(',');

        this.$editable.on('dblclick', mediaSelector, ev => {
            const targetEl = ev.currentTarget;
            let isEditable =
                // Check if the target element or its parent is content editable
                targetEl.isContentEditable ||
                (targetEl.parentElement && targetEl.parentElement.isContentEditable);

            // Further check if the target element should be editable
            if (!isEditable && targetEl.classList.contains('o_editable_media')) {
                isEditable = weUtils.shouldEditableMediaBeEditable(targetEl);
            }

            if (isEditable) {
                this.showTooltip = false;

                // Check if the current selection is not protected
                if (!isProtected(this.odooEditor.document.getSelection().anchorNode)) {
                    if (this.options.onDblClickEditableMedia && targetEl.nodeName === 'IMG' && targetEl.src) {
                        this.options.onDblClickEditableMedia(ev);
                    } else {
                        this._onDblClickEditableMedia(ev);
                    }
                }
            }
        });

        return res;
    },
});
