/** @odoo-module **/

import { patch } from "@web/core/utils/patch";
import { DocumentSelector } from "@web_editor/components/media_dialog/document_selector";


patch(DocumentSelector, {
    async createElements(selectedMedia, { orm }) {
        // Call the original createElements method
        const originalElements = await super.createElements(selectedMedia, { orm });

        // Add additional text content to each element
        return Promise.all(originalElements.map(linkEl => {
            if (linkEl instanceof HTMLAnchorElement) {
                linkEl.textContent = `${linkEl.title}`;
                linkEl.classList.add('document_link'); // Ensure the class is added
            }
            return linkEl;
        }));
    },

});

DocumentSelector.mediaSpecificClasses = ['document_link'];