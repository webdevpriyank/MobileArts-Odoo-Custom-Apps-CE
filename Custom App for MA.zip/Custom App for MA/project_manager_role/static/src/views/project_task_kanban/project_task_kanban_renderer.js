/** @odoo-module */

import { ProjectTaskKanbanRenderer } from '@project/views/project_task_kanban/project_task_kanban_renderer'; // Import your base class
import { useService } from '@web/core/utils/hooks';
import { onWillStart } from "@odoo/owl";

export class CustomProjectTaskKanbanRenderer extends ProjectTaskKanbanRenderer {
    setup() {
        super.setup();
        this.action = useService('action');
        const user = useService("user");
    
        onWillStart(async () => {
            // Await both group checks separately
            const isProjectManager = await user.hasGroup('project.group_project_manager');
            const isAnotherGroupMember = await user.hasGroup('project_manager_role.group_project_custom_manager');
    
            // Combine the results using the OR operator
            this.isProjectManager = isProjectManager || isAnotherGroupMember;
        });
    }

    
}
