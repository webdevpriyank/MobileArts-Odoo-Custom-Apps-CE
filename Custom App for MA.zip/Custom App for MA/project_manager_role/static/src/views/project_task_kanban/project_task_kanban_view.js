/** @odoo-module */

import { registry } from "@web/core/registry";
import { kanbanView } from '@web/views/kanban/kanban_view';
import { ProjectTaskKanbanModel } from "@project/views/project_task_kanban/project_task_kanban_model";
import { CustomProjectTaskKanbanRenderer } from '@project_manager_role/views/project_task_kanban/project_task_kanban_renderer'; // Import your custom renderer
import { ProjectControlPanel } from "@project/components/project_control_panel/project_control_panel";

export const customProjectTaskKanbanView = {
    ...kanbanView,
    Model: ProjectTaskKanbanModel,
    Renderer: CustomProjectTaskKanbanRenderer,
    ControlPanel: ProjectControlPanel,
};

// Register the custom Kanban view
registry.category('views').add('project_task_manager_kanban', customProjectTaskKanbanView);
