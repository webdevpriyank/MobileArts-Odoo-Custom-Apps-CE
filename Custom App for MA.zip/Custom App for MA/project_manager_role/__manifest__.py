# -*- coding: utf-8 -*-
{
    'name': "Project Manager Role",
    'summary': "Creates a new role for managing projects",
    'description': """
This module introduces a new role called 'Project Custom Manager' who can create new projects and access projects where they are project manager.
Author: Surabhi Varma (Mobibox Softech Pvt Ltd)
Website: https://www.mobiboxsoftech.com
    """,
    'author': 'Surabhi Varma (Mobibox Softech Pvt Ltd.)',
    'website': 'https://www.mobiboxsoftech.com/',
    'category': 'Services/Project',
    'version': '0.1',
    'depends': ['project'],
    'data': [
        'security/project_security.xml',
        'security/ir.model.access.csv',
        'views/project_task_views.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'project_manager_role/static/src/views/**/*',
        ],
    },
    'license': 'LGPL-3',
    'installable': True,
}
