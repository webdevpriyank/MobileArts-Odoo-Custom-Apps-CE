# -*- coding: utf-8 -*-

# from odoo import models, fields, api


# class project_manager_role(models.Model):
#     _name = 'project_manager_role.project_manager_role'
#     _description = 'project_manager_role.project_manager_role'

#     name = fields.Char()
#     value = fields.Integer()
#     value2 = fields.Float(compute="_value_pc", store=True)
#     description = fields.Text()
#
#     @api.depends('value')
#     def _value_pc(self):
#         for record in self:
#             record.value2 = float(record.value) / 100

