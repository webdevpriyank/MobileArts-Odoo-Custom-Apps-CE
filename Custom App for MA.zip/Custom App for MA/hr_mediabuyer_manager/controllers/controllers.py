# -*- coding: utf-8 -*-
# from odoo import http


# class HrMediabuyerManager(http.Controller):
#     @http.route('/hr_mediabuyer_manager/hr_mediabuyer_manager', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/hr_mediabuyer_manager/hr_mediabuyer_manager/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('hr_mediabuyer_manager.listing', {
#             'root': '/hr_mediabuyer_manager/hr_mediabuyer_manager',
#             'objects': http.request.env['hr_mediabuyer_manager.hr_mediabuyer_manager'].search([]),
#         })

#     @http.route('/hr_mediabuyer_manager/hr_mediabuyer_manager/objects/<model("hr_mediabuyer_manager.hr_mediabuyer_manager"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('hr_mediabuyer_manager.object', {
#             'object': obj
#         })

