# -*- coding: utf-8 -*-
{
    'name': "Appraisal-Evaluation Access Controller",

    'summary': "Enhances employee form view by adding visibility control for the appraisal and Evaluation page based on custom conditions.",

    'description': """
   This module extends the employee form view in Odoo, adding dynamic visibility controls for the 'evaluation' and 'appraisal' pages based on the following conditions:

   1. **Evaluation Page**:
      - The page is visible if all the following fields are true simultaneously: `is_manager`, `is_in_appraisal_group`, `is_mediabuyer`, and `is_in_medibuyer_group`.
     - The page remains hidden based on the default conditions unless all the above fields are true.

   2. **Appraisal Page**:
     - The page is visible if `is_manager`, `is_in_appraisal_group`, and `is_in_medibuyer_group` are true simultaneously.
     - The page is hidden if all the following fields are true: `is_manager`, `is_in_appraisal_group`, `is_in_medibuyer_group`, and `is_mediabuyer`.
     - The page remains hidden or visible based on the original logic if the above conditions are not met.

This customization allows for more tailored visibility of critical employee evaluation and appraisal information based on role and group memberships.
    """,

    'author': "Omkar Bari (Mobibox Softech Pvt Ltd)",
    'website': "https://mobiboxsoftech.com/",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/15.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base','hr_evaluation_mediabuyer','hr','kpi_management_system'],

    # always loaded
    'data': [
        # 'security/ir.model.access.csv',
        'security/security.xml',
        'views/views.xml',
        'views/HrMediabuyer.xml',
        'views/templates.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
}

