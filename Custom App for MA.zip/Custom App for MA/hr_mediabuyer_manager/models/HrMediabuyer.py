from odoo import models, fields, api


class Employee(models.Model):
    _inherit = 'hr.employee'

    is_in_medibuyer_group = fields.Boolean(compute='_compute_is_in_mediabuyer_group', store=False, string="Is PrimeAdmin")

    def _compute_is_in_mediabuyer_group(self):
        user_groups = self.env.user.groups_id.mapped('id')
        mediabuyer_group_id = self.env.ref('hr_mediabuyer_manager.group_employee_mediabuyer_manager').id
        for employee in self:
            employee.is_in_medibuyer_group = mediabuyer_group_id in user_groups

    is_in_appraisal_group = fields.Boolean(compute='_compute_is_in_appraisal_group', store=False, string="Is Supreme")

    def _compute_is_in_appraisal_group(self):
        user_groups = self.env.user.groups_id.mapped('id')
        appraisal_group_id = self.env.ref('hr_mediabuyer_manager.group_employee_appraisal_manager').id
        for employee in self:
            employee.is_in_appraisal_group = appraisal_group_id in user_groups



