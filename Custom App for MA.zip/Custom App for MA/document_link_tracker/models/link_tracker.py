from odoo import models, fields, api, _
import logging
from odoo.exceptions import AccessError

_logger = logging.getLogger(__name__)


class DocumentFolder(models.Model):
    _inherit = ['document.folder']

    document_urls = fields.One2many(
        comodel_name='document.folder.url',
        inverse_name='folder_id',
        string='Document URLs',
        auto_join=True,
        ondelete='cascade'
    )

    employee_count = fields.Integer(
        string="Number of Employees",
        compute='_compute_employee_count',
    )
    document_count = fields.Integer(
        string="Number of Documents",
        compute='_compute_document_count',
    )
    create_uid = fields.Many2one(
        'res.users',
        string='Created By',
        readonly=True,
        default=lambda self: self.env.user
    )

    current_date = fields.Date(
        string='Date',
        default=lambda self: fields.Date.today(),
        readonly=True
    )


    def unlink(self):
        for folder in self:
            # Check if the current user is the creator of the folder
            if folder.create_uid != self.env.user:
                raise AccessError(_("You are not allowed to delete this folder as you are not the creator."))

            # Delete all URLs and associated attachments before deleting the folder
            folder.document_urls.unlink()  # Delete related URLs
            folder.documents.unlink()  # Delete associated attachments

        return super(DocumentFolder, self).unlink()

    @api.depends('employee_ids')
    def _compute_employee_count(self):
        for folder in self:
            folder.employee_count = len(folder.employee_ids)

    @api.depends('documents')
    def _compute_document_count(self):
        for folder in self:
            folder.document_count = len(folder.documents)

    def _compute_document_urls(self):
        urls = []
        base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
        existing_urls = {url_record.name: url_record.url for url_record in self.document_urls}

        for document in self.documents:
            if document.name not in existing_urls:
                url = f"{base_url}/web/content/{document.id}?model=ir.attachment&field=datas&&filename={document.name}"
                urls.append((0, 0, {'name': document.name, 'url': url}))
            else:
                _logger.info(f"URL for document '{document.name}' already exists: {existing_urls[document.name]}")

        return urls

    @api.model
    def create(self, vals):
        documents = vals.pop('documents', False)
        folder = super(DocumentFolder, self).create(vals)
        if documents:
            folder.write({'documents': documents})
            folder.document_urls = folder._compute_document_urls()
        self._update_employee_group(folder.employee_ids)
        return folder

    def write(self, vals):
        # Get current attachments before the update
        current_attachments = set(self.documents.ids)
        document_commands = vals.get('documents', [])

        # Apply the super write method to perform the update
        res = super(DocumentFolder, self).write(vals)

        # Get the new attachments after the update
        new_attachments = set(self.documents.ids)

        # Determine which attachments were removed
        removed_attachments = current_attachments - new_attachments

        # Explicitly delete the removed attachments
        if removed_attachments:
            attachments_to_delete = self.env['ir.attachment'].browse(list(removed_attachments))
            attachments_to_delete.unlink()

        # Recompute document URLs if necessary
        if document_commands:
            for folder in self:
                folder.document_urls = folder._compute_document_urls()

        if 'employee_ids' in vals:
            for folder in self:
                self._update_employee_group(folder.employee_ids)

        return res

    def _update_employee_group(self, employees):
        group_user = self.env.ref('base.group_user')
        for employee in employees:
            if group_user not in employee.user_id.groups_id:
                employee.user_id.write({'groups_id': [(4, group_user.id)]})

class DocumentFolderURL(models.Model):
    _name = 'document.folder.url'
    _description = 'Document Folder URL'

    name = fields.Char(string='Document Name', required=True)
    url = fields.Char(string='Document URL', required=True)
    folder_id = fields.Many2one(
        comodel_name='document.folder',
        string='Folder',
        required=True,
        ondelete='cascade'
    )

    description = fields.Text(string='Description')

    def write(self, vals):
        # Capture the old name before the update
        old_names = {url.id: url.name for url in self}

        # Perform the update
        res = super(DocumentFolderURL, self).write(vals)

        # Check if the 'name' field was updated
        if 'name' in vals:
            for url_record in self:
                old_name = old_names.get(url_record.id)
                new_name = vals.get('name')

                if old_name and old_name != new_name:
                    # Find the related document in ir.attachment
                    related_doc = self.env['ir.attachment'].search([
                        ('res_model', '=', 'document.folder'),
                        ('res_id', '=', url_record.folder_id.id),
                        ('name', '=', old_name)
                    ], limit=1)

                    if related_doc:
                        # Update the document name
                        related_doc.write({'name': new_name})

        return res


class IrAttachment(models.Model):
    _inherit = 'ir.attachment'

    @api.model
    def check(self, mode, values=None):
        if self.env.context.get('public_access', False):
            return
        super(IrAttachment, self).check(mode, values)

    def unlink(self):
        # Delete the corresponding URLs when a document is deleted
        for attachment in self:
            document_urls = self.env['document.folder.url'].search([('name', '=', attachment.name)])
            if document_urls:
                document_urls.unlink()
        return super(IrAttachment, self).unlink()

