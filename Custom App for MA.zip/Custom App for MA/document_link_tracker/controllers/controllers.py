# -*- coding: utf-8 -*-
# from odoo import http


# class FolderLinkTracker(http.Controller):
#     @http.route('/document_link_tracker/document_link_tracker', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/document_link_tracker/document_link_tracker/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('document_link_tracker.listing', {
#             'root': '/document_link_tracker/document_link_tracker',
#             'objects': http.request.env['document_link_tracker.document_link_tracker'].search([]),
#         })

#     @http.route('/document_link_tracker/document_link_tracker/objects/<model("document_link_tracker.document_link_tracker"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('document_link_tracker.object', {
#             'object': obj
#         })

