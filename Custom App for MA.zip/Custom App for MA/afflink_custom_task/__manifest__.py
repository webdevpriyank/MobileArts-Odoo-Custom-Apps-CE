# -*- coding: utf-8 -*-
{
    'name': "Afflink Custom Task",
    'summary': "This module is specific for the Afflink project.",
    'description': """
This module adds necessary fields for the Afflink project in both the form and Kanban views.
Additionally, a new menu item "Afflink Operator" is included for managing operators and their respective countries.

Author: Surabhi Varma (Mobibox Softech Pvt Ltd)
Website: https://www.mobiboxsoftech.com
    """,
    'author': 'Surabhi Varma (Mobibox Softech Pvt Ltd)',
    'website': 'https://www.mobiboxsoftech.com',
    'category': 'Project Management',
    'version': '0.1',
    'depends': ['project'],
    'data': [
        'security/ir.model.access.csv',
        'security/afflink_security.xml',
        'views/afflink_country_views.xml',
        'views/afflink_operator_views.xml',
        'views/project_task_views.xml',
    ],
    'application': True,
    'installable': True,
    'license': 'LGPL-3',
}
