from odoo import fields, models


class AfflinkOperator(models.Model):
    _name = "afflink.operator"
    _description = "Afflink Operator"

    name = fields.Char("Operator Name")
    afflink_country_ids = fields.Many2many('afflink.country', string="Country")
