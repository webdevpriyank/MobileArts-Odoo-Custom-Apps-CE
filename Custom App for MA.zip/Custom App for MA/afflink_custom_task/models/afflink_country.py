from odoo import fields, models


class AfflinkCountry(models.Model):
    _name = "afflink.country"
    _description = "Afflink Country"

    name = fields.Char(string="Country name")