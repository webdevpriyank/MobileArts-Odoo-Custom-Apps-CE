# -*- coding: utf-8 -*-

from odoo import models, fields, api


class ProjectTask(models.Model):
    _inherit = "project.task"

    service_id = fields.Char(string="Service ID")
    cap = fields.Char(string="Cap")
    payout = fields.Char(string="Payout")
    afflink_country_id = fields.Many2one(comodel_name='afflink.country',string="Country") 
    afflink_operator_ids = fields.Many2many(string="Operators", comodel_name="afflink.operator", domain="[('afflink_country_ids', 'in', afflink_country_id)]")

    @api.onchange('afflink_country_id')
    def _onchange_afflink_country_id(self):
        if self.afflink_country_id:
            self.afflink_operator_ids = False
