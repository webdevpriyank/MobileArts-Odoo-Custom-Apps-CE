from odoo import api, fields, models
import base64
from datetime import datetime


class HrPayslip(models.Model):
    _inherit = 'hr.payslip'

    def action_send_payslip(self):
        self.ensure_one()

        # Generate the payslip report
        report = self.env['ir.actions.report']._render_qweb_pdf(
            'payroll.action_report_payslip', [self.id])
        payslip_report = base64.b64encode(report[0])  # Encode the PDF content

        # Create attachment
        attachment = self.env['ir.attachment'].create({
            'name': 'Payslip Report.pdf',
            'type': 'binary',
            'datas': payslip_report,
            'res_model': 'hr.payslip',
            'res_id': self.id,
            'mimetype': 'application/pdf'
        })

        # Format the payslip period (month and year)
        payslip_period = self.date_from.strftime('%B %Y')

        # Prepare email values
        email_values = {
            'subject': 'Payslip for %s' % self.employee_id.name,
            'body_html': '''
                        <p>Dear %s,</p>
                        <p>We are pleased to inform you that your payslip for the period %s is now available.</p>
                        <p>Please find your payslip attached to this email. If you have any questions or need further assistance, do not hesitate to reach out to the HR department.</p>
                        <p>Thank you for your continued hard work and dedication.</p>
                        <p>Best regards,<br/>%s</p>
                    ''' % (self.employee_id.name, payslip_period, self.employee_id.company_id.name),
            'email_to': self.employee_id.work_email,
            'attachment_ids': [(6, 0, [attachment.id])]
        }

        # Send email
        mail = self.env['mail.mail'].create(email_values)
        mail.send()

        return {
            'type': 'ir.actions.client',
            'tag': 'reload',
        }
