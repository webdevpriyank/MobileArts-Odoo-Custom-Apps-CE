# -*- coding: utf-8 -*-
# from odoo import http


# class CustomPayslipMail(http.Controller):
#     @http.route('/custom_payslip_mail/custom_payslip_mail', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/custom_payslip_mail/custom_payslip_mail/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('custom_payslip_mail.listing', {
#             'root': '/custom_payslip_mail/custom_payslip_mail',
#             'objects': http.request.env['custom_payslip_mail.custom_payslip_mail'].search([]),
#         })

#     @http.route('/custom_payslip_mail/custom_payslip_mail/objects/<model("custom_payslip_mail.custom_payslip_mail"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('custom_payslip_mail.object', {
#             'object': obj
#         })

