# -*- coding: utf-8 -*-
{
    'name': "Custom Payslip Email",

    'summary': "Automatically send payslips to employees via email.",

    'description': """
Custom Payslip Email Module
===========================

This module enhances the HR Payroll functionality by allowing payslips to be automatically sent to employees' registered email addresses directly from the payslip form view. 

Key Features:
-------------
- Adds a 'Send Payslip' button to the payslip form view.
- Automatically generates a PDF version of the payslip.
- Sends the payslip as an email attachment to the employee's work email.
- Streamlines payroll processing by eliminating the need for manual email sending.

Benefits:
---------
- Saves time and reduces errors in the payroll process.
- Ensures that employees receive their payslips promptly and securely.
- Improves HR efficiency and communication.

Author: Chirag Patel (Mobibox Softech Pvt Ltd)
Website: https://www.mobiboxsoftech.com
    """,

    'author': "Chirag Patel (Mobibox Softech Pvt Ltd.",
    'website': "https://mobiboxsoftech.com/",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/15.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Human Resources',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base', 'payroll', 'mail'],

    # always loaded
    'data': [
        # 'security/ir.model.access.csv',
        'views/hr_payslip_views.xml'
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
    'icon': '/custom_payslip_mail/static/description/icon.png'
}

