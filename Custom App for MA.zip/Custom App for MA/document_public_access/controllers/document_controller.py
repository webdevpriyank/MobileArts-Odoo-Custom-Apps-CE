
from odoo import http, _
from odoo.addons.portal.controllers.portal import CustomerPortal, pager as portal_pager
from odoo.exceptions import AccessError, MissingError
from odoo.http import request


class PortalAccount(CustomerPortal):

    @http.route(['/document/<int:document_id>'], type='http', auth="public", website=True)
    def portal_document_detail(self, document_id, access_token=None, report_type=None, download=False, **kw):
        try:
            document_sudo = self._document_check_access('ir.attachment', document_id, access_token)
        except (AccessError, MissingError):
            return request.not_found()

        values = {
            'document': document_sudo,
            'report_type': 'html',
        }
        values = self._get_page_view_values(
            document_sudo, access_token, values, 'my_document', False)

        return request.render('document_public_access.document_portal_layout', values)

    @http.route('/document/<int:document_id>/download', type='http', auth='public')
    def share_document(self, document_id, **kwargs):
        record = request.env['ir.attachment'].sudo().browse(document_id)
        if record:
            return request.env['ir.binary']._get_stream_from(record).get_response(as_attachment=True)
