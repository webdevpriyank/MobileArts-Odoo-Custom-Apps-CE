from odoo import http
from odoo.http import request
import base64


class DocumentPageController(http.Controller):

    @http.route('/document/public_page/<string:encoded_page_id>', type='http', auth='public', website=True)
    def public_document_page(self, encoded_page_id):
        try:
            page_id = int(base64.urlsafe_b64decode(encoded_page_id.encode()).decode())
        except (TypeError, ValueError):
            return request.not_found()

        page = request.env['document.page'].sudo().browse(page_id)
        if not page.exists():
            return request.not_found()

        return request.render('document_public_access.document_page_public_template', {
            'page': page,
        })
