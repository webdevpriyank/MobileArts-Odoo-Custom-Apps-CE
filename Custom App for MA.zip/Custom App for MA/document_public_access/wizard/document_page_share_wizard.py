from odoo import models, fields, api
import base64

class DocumentPageShareWizard(models.TransientModel):
    _name = 'document.page.share.wizard'
    _description = 'Document Page Share Wizard'

    page_id = fields.Many2one('document.page', string='Document Page', required=True, readonly=True)
    share_url = fields.Char(string='Share URL', readonly=True)

    @api.model
    def default_get(self, fields):
        res = super(DocumentPageShareWizard, self).default_get(fields)
        page = self.env['document.page'].browse(self._context.get('default_page_id'))
        if page:
            base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
            encoded_page_id = base64.urlsafe_b64encode(str(page.id).encode()).decode()
            share_url = f"{base_url}/document/public_page/{encoded_page_id}"
            res.update({
                'page_id': page.id,
                'share_url': share_url,
            })
        return res
