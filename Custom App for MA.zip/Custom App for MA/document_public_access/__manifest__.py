
{
    'name': "Documents Public Access",
    'summary': "Allow sharing documents publicly.",

    'description': """
    Documents Public Access
    =======================

    This module allows sharing links for documents so users can view them publicly.

    Key Features:
    -------------
    - Adds a 'Share' button inside server actions to the page and document form view.
    - A wizard is opened from where the link can be copied and shared with anyone.

    Benefits:
    ---------
    - Ensures that external users can easily view the document via a link.
    - Improves efficiency and communication.

    Author: Chirag Patel, Surabhi Varma (Mobibox Softech Pvt Ltd)
    Website: https://www.mobiboxsoftech.com
    """,

    'author': "Chirag Patel, Surabhi Varma (Mobibox Softech Pvt Ltd.)",
    'website': "https://mobiboxsoftech.com/",

    'category': 'Knowledge Management',
    'version': '0.1',
    "license": "LGPL-3",
    "depends": ["mail", "portal", "document_knowledge", "document_page"],
    "data": [
        "security/ir.model.access.csv",
        "views/document_knowledge.xml",
        "views/document_portal_views.xml",
        "views/document_page_portal_views.xml",
        "views/document_page.xml",
        "wizard/document_page_share_views.xml",
    ],
    "installable": True,
}
