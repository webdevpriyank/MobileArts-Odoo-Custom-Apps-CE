from odoo import models, fields

class DocumentPage(models.Model):
    _inherit = 'document.page'

    def action_share_document(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Share Content',
            'view_mode': 'form',
            'res_model': 'document.page.share.wizard',
            'target': 'new',
            'context': {'default_page_id': self.id},
        }
