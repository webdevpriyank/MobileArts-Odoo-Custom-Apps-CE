from odoo import models, fields


class DocumentKnowledge(models.Model):
    _name = "ir.attachment"
    _inherit = ['ir.attachment','portal.mixin', 'mail.thread', 'mail.activity.mixin']

    def _compute_access_url(self):
        super()._compute_access_url()
        for record in self:
            self.access_url = '/document/%s' % (record.id)
