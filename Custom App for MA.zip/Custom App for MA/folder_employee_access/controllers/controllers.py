# -*- coding: utf-8 -*-
# from odoo import http


# class FolderEmployeeAccess(http.Controller):
#     @http.route('/folder_employee_access/folder_employee_access', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/folder_employee_access/folder_employee_access/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('folder_employee_access.listing', {
#             'root': '/folder_employee_access/folder_employee_access',
#             'objects': http.request.env['folder_employee_access.folder_employee_access'].search([]),
#         })

#     @http.route('/folder_employee_access/folder_employee_access/objects/<model("folder_employee_access.folder_employee_access"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('folder_employee_access.object', {
#             'object': obj
#         })

