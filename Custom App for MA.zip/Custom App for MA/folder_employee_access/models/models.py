from odoo import models, api


class DocumentExtraFolderInherit(models.Model):
    _inherit = 'document.extra.folder'

    def write(self, vals):
        # Call the original write method of document.extra.folder
        res = super(DocumentExtraFolderInherit, self).write(vals)

        # Custom logic to update document.folder based on employee_ids
        for folder in self:
            if 'employee_ids' in vals:
                # Update the document.folder record for this folder
                folder_record = self.env['document.folder'].search([('parent_id', '=', folder.id)], limit=1)
                if folder_record:
                    folder_record.write({'employee_ids': [(6, 0, folder.employee_ids.ids)]})
                else:
                    self.env['document.folder'].create({
                        'parent_id': folder.id,
                        'employee_ids': [(6, 0, folder.employee_ids.ids)],
                    })

                # Update the parent document.folder record, if applicable
                if folder.parent_id:
                    parent_folder_record = self.env['document.folder'].search([('parent_id', '=', folder.parent_id.id)], limit=1)
                    if parent_folder_record:
                        parent_folder_record.write({'employee_ids': [(6, 0, folder.employee_ids.ids)]})
                    else:
                        self.env['document.folder'].create({
                            'parent_id': folder.parent_id.id,
                            'employee_ids': [(6, 0, folder.employee_ids.ids)],
                        })

        return res
