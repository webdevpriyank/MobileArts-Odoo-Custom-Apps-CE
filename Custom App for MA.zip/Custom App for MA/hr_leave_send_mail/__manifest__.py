{
    'name': 'Employee Leaves Mail',
    'version': '0.1',
    'category': 'Human Resources',
    'summary': 'HR Monthly Leaves Mail',
    'description': """
        HR Monthly Leaves Mail
        ======================
        This module allows receiving monthly leave updates of all employees in report format, sent via mail to HR.

        Key Features:
        -------------
        - Adds a "Receive Mail of Leaves" button inside the HR Settings page in Employees.
        - If this "Receive Mail of Leaves" is enabled for a particular employee, they will receive mail for leaves of all employees.
        - Adds a "Display in Mail" button in Time Off Types.
        - If "Display in Mail" is enabled for a time off type, that type will be included in the report sent via mail.

        Benefits:
        ---------
        - Ensures that employees are kept up to date.
        - Improves efficiency and communication.

        Author: Surabhi Varma (Mobibox Softech Pvt Ltd)
        Website: https://www.mobiboxsoftech.com
    """,

    'author': 'Surabhi Varma (Mobibox Softech Pvt Ltd.)',
    'website': 'https://mobiboxsoftech.com/',
    'depends': ['hr', 'hr_holidays'],
    'data': [
        'data/cron.xml',
        'data/mail_template_data.xml',
        'views/hr_leave_type_views.xml',
        'views/hr_employee_views.xml',
        'report/hr_leave_report.xml',
    ],
    'installable': True,
    'license': 'LGPL-3',
}
