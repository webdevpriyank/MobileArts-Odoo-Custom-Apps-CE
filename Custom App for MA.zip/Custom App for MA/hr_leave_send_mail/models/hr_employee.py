import base64
from collections import defaultdict
from odoo import api, models, fields
from odoo.exceptions import UserError

class HrEmploye(models.Model):
    _inherit = "hr.employee"

    receive_email = fields.Boolean("Monthly Leave Mail", help="Receive update of how much leaves remaining of the employees")

    def action_send_mail(self):
        recipients = self.env["hr.employee"].search([("receive_email", "=", True)])
        if not recipients:
            raise UserError('Recipients not found.')

        company_email = (
            self.env.company.email or
            self.env.company.partner_id.email_formatted
        )
        template = self.env.ref('hr_leave_send_mail.hr_leave_send_template')
        report = self.env.ref('hr_leave_send_mail.hr_leave_report')

        for recipient in recipients:
            employees = self.env["hr.employee"].search([('company_id', '=', recipient.company_id.id)])
            leave = defaultdict(lambda: defaultdict(lambda: {
                'max_leaves': 0,
                'virtual_remaining_leaves': 0,
                'remaining_leaves': 0,
                'leaves_taken': 0,
                'virtual_leaves_taken': 0
            }))
            for employee in employees:
                allocations = self.env['hr.leave.allocation'].search([('employee_id', '=', employee.id)])
                leaves_taken_tuple = employee._get_consumed_leaves(allocations.mapped('holiday_status_id'))
                if not isinstance(leaves_taken_tuple, tuple):
                    continue  # Skip if leaves_taken_tuple is not a tuple

                for leaves_taken in leaves_taken_tuple:
                    if not isinstance(leaves_taken, defaultdict):
                        continue  # Skip if leaves_taken is not a defaultdict

                    for employee, leave_types_data in leaves_taken.items():
                        for leave_type, allocations_data in leave_types_data.items():
                            for allocation, data in allocations_data.items():
                                leave[employee.id][leave_type.name]['max_leaves'] += data['max_leaves']
                                leave[employee.id][leave_type.name]['virtual_remaining_leaves'] += data['virtual_remaining_leaves']
                                leave[employee.id][leave_type.name]['remaining_leaves'] += data['remaining_leaves']
                                leave[employee.id][leave_type.name]['leaves_taken'] += data['leaves_taken']
                                leave[employee.id][leave_type.name]['virtual_leaves_taken'] += data['virtual_leaves_taken']

            leave_types = self.env['hr.leave.type'].search([('receive_leave_type_mail', '=', True)])

            data = dict(employees=employees, leave=leave, leave_types=leave_types)
            pdf_content, _ = report._render_qweb_pdf(report.id, data=data)
            if not pdf_content:
                raise UserError("The report content is empty.")
            pdf_base64 = base64.b64encode(pdf_content)

            attachment = self.env['ir.attachment'].create({
                'name': 'Employee_Leave_Monthly_Report.pdf',
                'type': 'binary',
                'datas': pdf_base64,
                'res_id': recipient.id,
                'res_model': 'hr.employee',
                'mimetype': 'application/pdf'
            })

            email_values = {
                'email_from': company_email,
                'attachment_ids': [(4, attachment.id)],
                'email_to': recipient.work_email,
            }

            template.send_mail(recipient.id, force_send=True, email_values=email_values)
            attachment.unlink()
