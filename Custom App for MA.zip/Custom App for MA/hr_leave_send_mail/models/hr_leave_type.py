import base64
from datetime import datetime, timedelta
from collections import defaultdict
from odoo import api, models, fields

class HrLeaveType(models.Model):
    _inherit = "hr.leave.type"

    receive_leave_type_mail = fields.Boolean("Display in Mail", help="Receive update of this leave type in mail")
