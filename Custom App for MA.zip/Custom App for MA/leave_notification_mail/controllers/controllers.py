# -*- coding: utf-8 -*-
# from odoo import http


# class TimeOffNotify(http.Controller):
#     @http.route('/time_off_notify/time_off_notify', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/time_off_notify/time_off_notify/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('time_off_notify.listing', {
#             'root': '/time_off_notify/time_off_notify',
#             'objects': http.request.env['time_off_notify.time_off_notify'].search([]),
#         })

#     @http.route('/time_off_notify/time_off_notify/objects/<model("time_off_notify.time_off_notify"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('time_off_notify.object', {
#             'object': obj
#         })

