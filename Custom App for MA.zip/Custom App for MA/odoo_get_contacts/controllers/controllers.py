from odoo import http
from odoo.http import request, Response
import json
import time
import cachetools

# Initialize cache
cache = cachetools.TTLCache(maxsize=100, ttl=600)

class AfflinkController(http.Controller):
    
    @http.route('/api/get_contacts', auth='user', methods=['GET'], csrf=False)
    def get_contacts(self):
        cache_key = 'api.contacts.data'

        # Check if data is cached
        if cache_key in cache:
            json_data, cache_timestamp = cache[cache_key].split('|', 1)
        else:
            # Fetch data from the database
            contacts = request.env['res.partner'].search([])

            contact_data = []
            for contact in contacts:
                contact_info = {}
                for field_name, field_value in contact._fields.items():
                    try:
                        value = contact[field_name]
                        
                        if field_value.type in ('many2one', 'one2many', 'many2many', 'binary'):
                            continue

                        contact_info[field_name] = value
                    except Exception as e:
                        contact_info[field_name] = None
                contact_data.append(contact_info)

            json_data = json.dumps({'contacts': contact_data}, default=str)
            
            cache_timestamp = str(int(time.time()))

            # Cache the data
            cache[cache_key] = f"{json_data}|{cache_timestamp}"

        if request.httprequest.headers.get('If-None-Match') == cache_timestamp:
            return Response(status=304)

        headers = [
            ('ETag', cache_timestamp),
            ('Cache-Control', f"max-age={http.STATIC_CACHE}"),
            ('Content-Type', 'application/json'),
        ]
        return Response(json_data, headers=headers)


