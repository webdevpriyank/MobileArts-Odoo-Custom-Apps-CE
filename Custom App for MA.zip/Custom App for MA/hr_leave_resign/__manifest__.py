# -*- coding: utf-8 -*-
{
    'name': "hr_leave_resign",
    'category': 'Uncategorized',
    'version': '0.1',
    'summary': "Calculate the extra leaves of employees on the last working day",

    'description': """
        While archiving an employee a wizard opens, there the option for selecting last working date must be chosen and according to that extra leaves 
        remaining of employee to be paid by company or extra leaves taken by employee paid by employee till that date will be calculated

        Author: Surabhi Varma (Mobibox Softech Pvt Ltd)
        Website: https://www.mobiboxsoftech.com

    """,

    'author': 'Surabhi Varma (Mobibox Softech Pvt Ltd.)',
    'website': 'https://mobiboxsoftech.com/',

    # any module necessary for this one to work correctly
    'depends': ['hr_holidays'],

    # always loaded
    'data': [
        'views/hr_employee_views.xml',
        'views/hr_departure_wizard_views.xml',
    ],
    'demo': [
    ],
    'installable': True,
    'license': 'LGPL-3',
}
