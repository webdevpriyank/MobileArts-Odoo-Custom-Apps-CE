from collections import defaultdict
from odoo import api, fields, models
from datetime import date


class HrDepartureWizard(models.TransientModel):
    _inherit = 'hr.departure.wizard'

    last_working_date = fields.Date("Last Working Date", default=lambda self: fields.Date.today())
    extra_leaves_utilized = fields.Float(string="Extra Leaves Utilized", compute="_compute_extra_leaves")
    leaves_due_compensation = fields.Float(string="Leaves Due for Compensation", compute="_compute_extra_leaves")

    @api.depends('last_working_date')
    def _compute_extra_leaves(self):
        for wizard in self:
            current_year = date.today().year
            employee = wizard.employee_id
            leave_type_ids_of_interest = [49, 98, 39]

            allocations = self.env['hr.leave.allocation'].search([('employee_id', '=', employee.id),('holiday_status_id', 'in', leave_type_ids_of_interest)])
            all_leaves = employee._get_consumed_leaves(allocations.mapped('holiday_status_id'))[0]
        
            leave_aggregation = defaultdict(lambda: defaultdict(lambda: {
                'max_leaves': 0,
                'virtual_remaining_leaves': 0,
                'remaining_leaves': 0,
                'leaves_taken': 0,
                'virtual_leaves_taken': 0
            }))
            
            last_working_date = wizard.last_working_date
            current_month = fields.Date.from_string(last_working_date).month if last_working_date else 0
            current_year = fields.Date.from_string(last_working_date).year if last_working_date else 0

            for leave_type in all_leaves[employee]:
                # Filter allocations where both date_from and date_to are within the current year
                allocations_in_current_year = allocations.filtered(
                    lambda a: a.holiday_status_id == leave_type and
                    a.date_from.year == current_year and
                    a.date_to.year == current_year
                )
                for allocation in allocations_in_current_year:
                    leave_aggregation[employee.id][leave_type.id]['max_leaves'] += all_leaves[employee][leave_type][allocation]['max_leaves']
                    leave_aggregation[employee.id][leave_type.id]['virtual_remaining_leaves'] += all_leaves[employee][leave_type][allocation]['virtual_remaining_leaves']
                    leave_aggregation[employee.id][leave_type.id]['remaining_leaves'] += all_leaves[employee][leave_type][allocation]['remaining_leaves']
                    leave_aggregation[employee.id][leave_type.id]['leaves_taken'] += all_leaves[employee][leave_type][allocation]['leaves_taken']
                    leave_aggregation[employee.id][leave_type.id]['virtual_leaves_taken'] += all_leaves[employee][leave_type][allocation]['virtual_leaves_taken']

            leave_interest = self.env['hr.leave.type'].search([
                ('id', 'in', leave_type_ids_of_interest),
                ('company_id', '=', employee.company_id.id)
            ])

            leave_type_id = leave_interest.ids[0] if leave_interest else None
            if leave_type_id:
                max_leaves = leave_aggregation[employee.id][leave_type_id]['max_leaves']
                leaves_taken = leave_aggregation[employee.id][leave_type_id]['leaves_taken']

                if current_month > 0:
                    extra_leaves = leaves_taken - (current_month * (max_leaves / 12))
                else:
                    extra_leaves = 0

                if extra_leaves < 0:
                    wizard.extra_leaves_utilized = 0
                    wizard.leaves_due_compensation = abs(extra_leaves)
                else:
                    wizard.extra_leaves_utilized = extra_leaves
                    wizard.leaves_due_compensation = 0
            else:
                wizard.extra_leaves_utilized = 0
                wizard.leaves_due_compensation = 0

    def action_register_departure(self):
        employee = self.employee_id
        employee.last_working_date = self.last_working_date
        employee.extra_leaves_utilized = self.extra_leaves_utilized
        employee.leaves_due_compensation = self.leaves_due_compensation
        super(HrDepartureWizard, self).action_register_departure()
