from odoo import models, fields

class Employee(models.Model):
    _inherit = "hr.employee"

    last_working_date = fields.Date("Last Working Date")
    extra_leaves_utilized = fields.Float(string="Extra Leaves Utilized")
    leaves_due_compensation = fields.Float(string="Leaves Due for Compensation")
