# -*- coding: utf-8 -*-

from . import hr_employee
from . import hr_departure_wizard