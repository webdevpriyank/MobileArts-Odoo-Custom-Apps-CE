from odoo import models, fields, api


class DocumentFolder(models.Model):
    _inherit = 'document.folder'


class DocumentExtraFolderInherit(models.Model):
    _inherit = 'document.extra.folder'

    def unlink(self):
        # Deleting related records in the document.folder model
        for folder in self:
            # Find the corresponding document.folder record
            folder_record = self.env['document.folder'].search([('parent_id', '=', folder.id)])
            if folder_record:
                folder_record.unlink()

        # Call the original unlink method to delete the folder
        return super(DocumentExtraFolderInherit, self).unlink()

