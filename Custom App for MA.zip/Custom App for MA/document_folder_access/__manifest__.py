# -*- coding: utf-8 -*-
{
    'name': "Folder Controller",

    'summary': "Extends the Document Extra Folder functionality to delete related document.folder records upon deletion.",

    'description': """
    This module extends the existing functionality of the Document Extra Folder model.
        When a folder is deleted, the corresponding record in the document.folder model
        is also deleted automatically. The implementation is done through inheritance,
        ensuring that the original functionality remains unchanged.    """,

    'author': "Omkar Bari (Mobibox Softech Pvt Ltd)",
    'website': "https://mobiboxsoftech.com/",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/15.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base','document_management'],

    # always loaded
    'data': [
        # 'security/ir.model.access.csv',
        'views/views.xml',
        'views/FolderCreateAccess.xml',
        'views/templates.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
}

