# -*- coding: utf-8 -*-
# from odoo import http


# class DocumentFolderAccess(http.Controller):
#     @http.route('/document_folder_access/document_folder_access', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/document_folder_access/document_folder_access/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('document_folder_access.listing', {
#             'root': '/document_folder_access/document_folder_access',
#             'objects': http.request.env['document_folder_access.document_folder_access'].search([]),
#         })

#     @http.route('/document_folder_access/document_folder_access/objects/<model("document_folder_access.document_folder_access"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('document_folder_access.object', {
#             'object': obj
#         })

