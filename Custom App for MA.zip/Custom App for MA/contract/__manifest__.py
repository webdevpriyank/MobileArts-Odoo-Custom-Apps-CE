{
    'name': "Contract Management",
    'version': '0.1',
    'summary': 'Manage contracts with customers efficiently.',
    'description': """
        This module facilitates the creation and management of contracts with customers.

        Key Features:
        -------------
        - Add a "Contract" app for contract creation and management.
        - Access control: Only the creator or responsible employee can view the contract.
        - Dashboard: View counts of expired, running, and all contracts.
        - Automatic email notifications: Notify clients 10 days before and on the contract's expiry date.

        Author: Surabhi Varma (Mobibox Softech Pvt Ltd)
        Website: https://www.mobiboxsoftech.com
    """,
    'author': 'Surabhi Varma (Mobibox Softech Pvt Ltd)',
    'website': 'https://www.mobiboxsoftech.com',

    'depends': ['contacts', 'hr', 'mail'],
    'data': [
        'data/cron.xml',
        'data/contract_mail_template.xml',
        'security/ir.model.access.csv',
        'views/contract_type_views.xml',
        'views/contract_document_views.xml',
        'views/contract_views.xml',
    ],

    'assets': {
        'web.assets_backend': [
            'contract/static/src/views/*.js',
            'contract/static/src/**/*.xml',
        ],
    },
    
    'application': True,
    'installable': True,
    'license': 'LGPL-3',
}
