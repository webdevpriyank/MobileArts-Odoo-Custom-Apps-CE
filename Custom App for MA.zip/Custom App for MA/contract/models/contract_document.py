from odoo import models , fields , api

from odoo.exceptions import ValidationError

class ContractDocument(models.Model):
    _name = 'contract.document'
    _description = "Contract Document"

    name = fields.Char(string="Document Name")
    data = fields.Binary()
    filename = fields.Char(compute="_compute_filename")
    contract_id = fields.Many2one('contract.contract')

    @api.depends('name', 'contract_id')
    def _compute_filename(self):
        for doc in self:
            doc.filename = f'{doc.contract_id.name}-{doc.name}'
    