from odoo import models , fields , api
from datetime import timedelta
from odoo.exceptions import UserError

class Contract(models.Model):
    _name = 'contract.contract'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name=fields.Char(string="Contract Name", required=True, tracking=True)
    client_id=fields.Many2one('res.partner', string="Client", tracking=True, required=True)
    client_email=fields.Char(related='client_id.email', readonly=False, required=True)
    client_address=fields.Char(string="Address", related='client_id.contact_address', readonly=False)

    contract_company_id=fields.Many2one("res.company", default=lambda self:self.env.company, required=True)
    responsible_employee_id=fields.Many2one('hr.employee', default=lambda self:self.env.user.employee_id)
    contract_type_id=fields.Many2one("contract.type", tracking=True)


    amount = fields.Float(string="Amount (In USD)", tracking=True)
    discount = fields.Float(string="Discount (In Percent)")
    warranty = fields.Float(string="Warranty (In Years)")

    start_date=fields.Date(default=lambda self:fields.Date.today(), tracking=True, required=True)
    end_date=fields.Date(required=True, tracking=True)
    frequency = fields.Selection(string="Contract frequency", selection=[('monthly','Monthly'),('quarterly','Quraterly'),('half_yearly','Half Yearly'),('yearly','Yearly')], required=True)
    
    last_renewal_date=fields.Date()
    is_contract_renewable = fields.Boolean("Is Contract Renewable?")
    renewal_amount = fields.Float("Renewal Amount (In USD)")
    description=fields.Html()

    is_expired=fields.Boolean(compute="_compute_is_expired", store=True)
    contract_document_ids = fields.One2many("contract.document", 'contract_id')


    @api.constrains('end_date')
    def _check_end_date(self):
        for contract in self:
            if contract.end_date < contract.start_date:
                raise UserError("Contract End Date should not be less than Start Date.")

    @api.depends('end_date')
    def _compute_is_expired(self):
        today = fields.Date.today()
        for contract in self:
            contract.is_expired = contract.end_date and contract.end_date < today

    def contract_end_send_mail(self):
        template_id = self.env.ref('contract.contract_expiry_mail_template')
        current_date = fields.Date.today()
        ten_days_later = current_date + timedelta(days=10)
        contracts = self.search([
            '|',
            ('end_date', '=', current_date),
            ('end_date', '=', ten_days_later)
        ])

        for contract in contracts:
            print("Contract", contract)
            if template_id:
                template_id.send_mail(contract.id, force_send=True)


    @api.model
    def get_dashboard_data(self):
        result = {
            'expired': 0,
            'running': 0,
            'all_contracts': 0,
        }
        base_domain = [
            '|', 
                '|', 
                ('create_uid','=',self.env.user.id), 
                ('responsible_employee_id', '=', self.env.user.employee_id.id), 
                ('message_is_follower', '=', True)
        ]

        contract = self.env['contract.contract']

        result['expired'] = contract.search_count(base_domain + [('is_expired', '=', True)])
        result['running'] = contract.search_count(base_domain + [('is_expired', '=', False)])
        result['all_contracts'] = contract.search_count(base_domain)
        return result
    
# Partner Company Name

# Partner Company Address
# Partner Company Email
# Partner Company Contact Person

# Our Company Name
# Our Company Responsible User

# Contract Type
# Contract Start Date
# Contract End Date

# Contract Amount in USD
# Contract Discount 
# Contract Warranty

# Is Contract Renewable?
# Contract Renewal Amount in USD


