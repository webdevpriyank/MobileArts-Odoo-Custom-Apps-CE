/** @odoo-module **/

import { registry } from "@web/core/registry";
import { listView } from "@web/views/list/list_view";
import { ListRenderer } from "@web/views/list/list_renderer";
import { ContractDashBoard } from '@contract/views/contract_dashboard';

export class ContractDashBoardRenderer extends ListRenderer {};

ContractDashBoardRenderer.template = 'contract.ContractListView';
ContractDashBoardRenderer.components= Object.assign({}, ListRenderer.components, {ContractDashBoard})

export const ContractDashBoardListView = {
    ...listView,
    Renderer: ContractDashBoardRenderer,
};

registry.category("views").add("contract_dashboard_list", ContractDashBoardListView);
