# -*- coding: utf-8 -*-
# from odoo import http


# class CrmRecordGlobal(http.Controller):
#     @http.route('/crm_record_global/crm_record_global', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/crm_record_global/crm_record_global/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('crm_record_global.listing', {
#             'root': '/crm_record_global/crm_record_global',
#             'objects': http.request.env['crm_record_global.crm_record_global'].search([]),
#         })

#     @http.route('/crm_record_global/crm_record_global/objects/<model("crm_record_global.crm_record_global"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('crm_record_global.object', {
#             'object': obj
#         })

