from odoo import models, api, SUPERUSER_ID


class CrmLead(models.Model):
    _inherit = 'crm.lead'

    @api.model
    def _read_group_stage_ids(self, stages, domain, order):
        user = self.env.user
        user_team_ids = user.sale_team_id.ids if user.sale_team_id else []

        # If user is in any team, show only stages assigned to their team
        if user_team_ids:
            search_domain = ['|', ('id', 'in', stages.ids), ('team_id', 'in', user_team_ids)]
        else:
            # If user is not in any team, show only stages not assigned to any team
            search_domain = ['|', ('id', 'in', stages.ids), ('team_id', '=', False)]

        # Perform the search
        stage_ids = stages._search(search_domain, order=order, access_rights_uid=SUPERUSER_ID)
        return stages.browse(stage_ids)
